const { success, error } = require('../../../common/response');
const pool = require('../../../common/db');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

exports.handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const { username, email, password } = body;

        if (!username || !email || !password) {
            return error('Missing required fields');
        }

        const [existingUsers] = await pool.execute(
            'SELECT * FROM users WHERE email = ? OR username = ?',
            [email, username]
        );

        if (existingUsers.length > 0) {
            return error('Email or username already in use');
        }

        const passwordHash = await bcrypt.hash(password, 10);
        const userId = uuidv4();

        await pool.execute(
            'INSERT INTO users (user_id, username, email, password_hash) VALUES (?, ?, ?, ?)',
            [userId, username, email, passwordHash]
        );

        return success({ message: 'User registered successfully', userId });
    } catch (err) {
        console.error(err);
        return error('Failed to register user');
    }
};
